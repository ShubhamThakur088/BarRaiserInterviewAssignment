import React from "react";

function Structure() {
  return <></>;
}
