import "./styles.css";

const Animals = [
  {
    key: "cat.png",
    //modified: +Moment().subtract(1, "hours"),
    size: 1.5 * 1024 * 1024
  },
  {
    key: "kitten.png",
    // modified: +Moment().subtract(3, "days"),
    size: 545 * 1024
  },
  {
    key: "elephant.png",
    // modified: Moment().subtract(3, "days"),
    size: 52 * 1024
  }
];

export default function App() {
  // var startdate = moment().subtract(1, "days").format("DD-MM-YYYY");
  // console.log(Animals[0].key);
  return (
    <>
      <div>
        <input type="text" placeholder="Search Files"></input>
        <button>Add folder</button>
        <button>delete</button>
      </div>
      <br />
      <table className="Table-Container">
        <tr>
          <th>Files</th>
          <th>Size</th>
          <th>Modified</th>
        </tr>
        <tr>
          <td>{Animals[0].key}</td>
          <td>{Animals[0].size}</td>
          <td>{}</td>
        </tr>
        <tr>
          <td>{Animals[1].key}</td>
          <td>{Animals[1].size}</td>
        </tr>
        <tr>
          <td>{Animals[2].key}</td>
          <td>{Animals[2].size}</td>
        </tr>
      </table>
    </>
  );
}
